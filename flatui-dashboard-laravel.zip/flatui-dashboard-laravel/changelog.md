# Changelog

All notable changes to `FlatUI Dashboard` frontend preset for Laravel will be documented in this file.

## Version 1.0.0

### Added
- FlatUI Dashboard v1.0.0 frontend theme
- Laravel Auth preset
- Change user profile
- User CRUD

## Version 1.0.0 - Version 1.0.4
- Bugfixes